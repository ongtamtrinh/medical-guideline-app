// components/MermaidFlowchart.tsx
'use client';
import { useMermaid } from 'react-x-mermaid';
import { useEffect, useRef } from 'react';

interface FlowNode { nodeId: string; label: string; action: string; payload: string; }

interface Props {
  chart: string;
  nodes: FlowNode[];
  darkMode: boolean;
}

export default function MermaidFlowchart({ chart, nodes, darkMode }: Props) {
  const { ref, error } = useMermaid(chart, {
    theme: darkMode ? 'dark' : 'default',
  });

  // Gắn click handler vào các node Mermaid SVG
  useEffect(() => {
    if (!ref.current) return;
    nodes.forEach((node) => {
      const el = ref.current?.querySelector(`[id*="${node.nodeId}"]`);
      if (el) {
        (el as HTMLElement).style.cursor = 'pointer';
        el.addEventListener('click', () => {
          if (node.action === 'show_alert') alert(node.payload);
          if (node.action === 'link_medication') {
            document.getElementById(node.payload)?.scrollIntoView({ behavior: 'smooth' });
          }
        });
      }
    });
  }, [ref, nodes]);

  if (error) return <pre className="text-red-500 text-xs">{error}</pre>;
  return (
    <div
      ref={ref}
      className="w-full overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700 p-4 bg-white dark:bg-gray-900"
    />
  );
}