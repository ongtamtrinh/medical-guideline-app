// components/PatientEducationModal.tsx
'use client';
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import type { GuidelineProtocol } from '@/types/guideline';
import { generatePatientEducation } from '@/lib/ai-actions'; // Server Action

interface Props {
  open: boolean;
  onClose: () => void;
  guideline: GuidelineProtocol;
}

export default function PatientEducationModal({ open, onClose, guideline }: Props) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(guideline.patientEducation);

  async function handleGenerate() {
    setLoading(true);
    try {
      const edu = await generatePatientEducation(guideline);
      setResult(edu);
    } finally {
      setLoading(false);
    }
  }

  async function handleExportPDF() {
    const { exportPatientPDF } = await import('@/lib/pdf-export');
    exportPatientPDF(result!);
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>📋 Phiếu hướng dẫn bệnh nhân</DialogTitle>
        </DialogHeader>

        {!result ? (
          <div className="text-center py-8 space-y-4">
            <p className="text-sm text-gray-500">AI sẽ tóm tắt phác đồ thành ngôn ngữ bình dân.</p>
            <Button onClick={handleGenerate} disabled={loading} className="gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {loading ? 'Đang tạo...' : 'Tạo phiếu với AI'}
            </Button>
          </div>
        ) : (
          <div className="space-y-4 text-sm">
            <h3 className="font-bold text-base">{result.title}</h3>
            <p className="text-gray-600 dark:text-gray-400">{result.plainTextSummary}</p>

            <div>
              <h4 className="font-semibold mb-1">💊 Hướng dẫn uống thuốc</h4>
              <ul className="list-disc list-inside space-y-1">
                {result.medicationGuide.map((g, i) => <li key={i}>{g}</li>)}
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-1">🥗 Chế độ ăn uống</h4>
              <ul className="list-disc list-inside space-y-1">
                {result.dietAdvice.map((d, i) => <li key={i}>{d}</li>)}
              </ul>
            </div>

            <div className="bg-red-50 dark:bg-red-950/30 rounded-lg p-3 border border-red-200 dark:border-red-800">
              <h4 className="font-semibold text-red-700 dark:text-red-400 mb-1">
                🚨 Khi nào cần nhập viện ngay
              </h4>
              <ul className="list-disc list-inside space-y-1 text-red-700 dark:text-red-300">
                {result.warningSignsGoToER.map((w, i) => <li key={i}>{w}</li>)}
              </ul>
            </div>

            <p className="text-xs text-gray-500">Tái khám: {result.followUp}</p>

            <div className="flex gap-2 pt-2">
              <Button onClick={handleExportPDF} className="flex-1 gap-1">
                📥 Xuất PDF / Gửi Zalo
              </Button>
              <Button variant="outline" onClick={handleGenerate} disabled={loading}>
                🔄 Tạo lại
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}