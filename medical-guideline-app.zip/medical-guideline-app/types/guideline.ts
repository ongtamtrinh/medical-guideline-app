export interface RedFlag {
  text: string;
  severity: 'warning' | 'danger' | 'critical';
}

export interface Dosage {
  fixed?: string;
  perKg?: number;
  perKgPerDay?: number;
  maxDose?: number;
  frequency?: string;
  duration?: string;
}

export interface NursingNote {
  preparation: string;
  infusionRate: string;
  monitoring: string[];
  incompatible: string[];
}

export interface Medication {
  name: string;
  generic: string;
  route: string;
  dosage: Dosage;
  nursingNote?: NursingNote;
  contraindications?: string[];
  isRedFlag?: boolean;
}

export interface PatientEducation {
  language: string;
  title: string;
  plainTextSummary: string;
  medicationGuide: string[];
  dietAdvice: string[];
  warningSignsGoToER: string[];
  followUp: string;
  generatedAt: string;
}

export interface AuditEntry {
  userId: string;
  userName: string;
  action: 'created' | 'edited' | 'approved' | 'archived';
  timestamp: string;
  diff?: string;
}

export interface GuidelineProtocol {
  id: string;
  qrCode: string;
  metadata: {
    title: string;
    specialty: string;
    icdCode: string;
    version: string;
    status: 'draft' | 'active' | 'archived';
    approvedBy?: string;
    approvedAt?: string;
    sourceFile?: string;
  };
  auditTrail: AuditEntry[];
  diagnosis: {
    definition: string;
    symptoms: string[];
    redFlags: RedFlag[];
    diagnosticCriteria: string[];
  };
  investigations: {
    name: string;
    type: string;
    normalRange?: string;
    urgency: 'routine' | 'urgent' | 'stat';
  }[];
  medications: Medication[];
  flowchart: {
    mermaidCode: string;
    nodes: { nodeId: string; label: string; action: string; payload: string }[];
  };
  patientEducation?: PatientEducation;
}