// app/phac-do/[id]/page.tsx
'use client';

import { useState } from 'react';
import { useTheme } from 'next-themes';
import dynamic from 'next/dynamic';
import { QRCodeSVG } from 'qrcode.react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Moon, Sun, Printer, QrCode, History, Stethoscope } from 'lucide-react';
import DosageCalculator from '@/components/DosageCalculator';
import PatientEducationModal from '@/components/PatientEducationModal';
import AuditTrailDrawer from '@/components/AuditTrailDrawer';
import type { GuidelineProtocol } from '@/types/guideline';

// Lazy load Mermaid (client-only, nặng)
const MermaidFlowchart = dynamic(() => import('@/components/MermaidFlowchart'), { ssr: false });

interface Props {
  guideline: GuidelineProtocol;
}

export default function GuidelineDetailPage({ guideline }: Props) {
  const { theme, setTheme } = useTheme();
  const [isNursingView, setIsNursingView] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [showAudit, setShowAudit] = useState(false);
  const [showPatientEdu, setShowPatientEdu] = useState(false);
  const [patientWeight, setPatientWeight] = useState<number | null>(null);

  const isDark = theme === 'dark';

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-50 transition-colors">
      {/* ── HEADER ── */}
      <header className="sticky top-0 z-50 border-b border-gray-200 dark:border-gray-800 bg-white/80 dark:bg-gray-950/80 backdrop-blur-sm px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold leading-tight">{guideline.metadata.title}</h1>
            <div className="flex gap-2 mt-1 flex-wrap">
              <Badge variant="outline">{guideline.metadata.specialty}</Badge>
              <Badge variant="secondary">{guideline.metadata.icdCode}</Badge>
              <Badge
                className={
                  guideline.metadata.status === 'active'
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-yellow-100 text-yellow-800'
                }
              >
                {guideline.metadata.version}
              </Badge>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(isDark ? 'light' : 'dark')}
              title="Chuyển chế độ sáng/tối"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <Button
              variant={isNursingView ? 'default' : 'outline'}
              size="sm"
              onClick={() => setIsNursingView(!isNursingView)}
              className="gap-1"
            >
              <Stethoscope className="w-4 h-4" />
              {isNursingView ? 'Bác sĩ' : 'Điều dưỡng'}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setShowQR(!showQR)}>
              <QrCode className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setShowAudit(true)}>
              <History className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* ── QR CODE ── */}
        {showQR && (
          <div className="flex justify-center p-4 border rounded-xl dark:border-gray-700">
            <QRCodeSVG
              value={guideline.qrCode}
              size={180}
              bgColor={isDark ? '#030712' : '#ffffff'}
              fgColor={isDark ? '#f9fafb' : '#111827'}
            />
          </div>
        )}

        {/* ── RED FLAGS ── */}
        {guideline.diagnosis.redFlags?.length > 0 && (
          <div className="space-y-2">
            <h2 className="text-sm font-semibold text-red-600 dark:text-red-400 uppercase tracking-wide flex items-center gap-1">
              <AlertTriangle className="w-4 h-4" /> DẤU HIỆU NGUY HIỂM
            </h2>
            {guideline.diagnosis.redFlags.map((flag, i) => (
              <Alert
                key={i}
                className={`border-l-4 ${
                  flag.severity === 'critical'
                    ? 'border-red-600 bg-red-50 dark:bg-red-950/40'
                    : flag.severity === 'danger'
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/40'
                    : 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950/40'
                }`}
              >
                <AlertTriangle
                  className={`w-4 h-4 ${
                    flag.severity === 'critical'
                      ? 'text-red-600'
                      : flag.severity === 'danger'
                      ? 'text-orange-500'
                      : 'text-yellow-500'
                  }`}
                />
                <AlertDescription className="font-medium">{flag.text}</AlertDescription>
              </Alert>
            ))}
          </div>
        )}

        {/* ── TABS CHÍNH ── */}
        <Tabs defaultValue="diagnosis">
          <TabsList className="w-full grid grid-cols-4 h-auto">
            <TabsTrigger value="diagnosis" className="text-xs py-2">Chẩn đoán</TabsTrigger>
            <TabsTrigger value="treatment" className="text-xs py-2">Điều trị</TabsTrigger>
            <TabsTrigger value="flowchart" className="text-xs py-2">Sơ đồ</TabsTrigger>
            <TabsTrigger value="cls" className="text-xs py-2">Cận LS</TabsTrigger>
          </TabsList>

          {/* Tab: Chẩn đoán */}
          <TabsContent value="diagnosis" className="mt-4 space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              {guideline.diagnosis.definition}
            </p>
            <div>
              <h3 className="font-semibold mb-2">Triệu chứng lâm sàng</h3>
              <ul className="space-y-1">
                {guideline.diagnosis.symptoms.map((s, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <span className="mt-1 w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          </TabsContent>

          {/* Tab: Điều trị */}
          <TabsContent value="treatment" className="mt-4 space-y-4">
            {/* Dosage Calculator */}
            <DosageCalculator onWeightChange={setPatientWeight} />

            {guideline.medications.map((med, i) => (
              <div
                key={i}
                className={`rounded-xl border p-4 space-y-2 ${
                  med.isRedFlag
                    ? 'border-red-400 dark:border-red-700 bg-red-50/50 dark:bg-red-950/20'
                    : 'border-gray-200 dark:border-gray-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-semibold">{med.name}</span>
                    <span className="text-xs text-gray-500 ml-2">({med.generic})</span>
                  </div>
                  {med.isRedFlag && (
                    <Badge className="bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 text-xs">
                      ⚠ Thận trọng
                    </Badge>
                  )}
                </div>

                {/* Tính liều động */}
                {med.dosage.perKg && patientWeight ? (
                  <div className="text-sm bg-blue-50 dark:bg-blue-950/30 rounded-lg p-3 border border-blue-200 dark:border-blue-800">
                    <span className="font-medium text-blue-700 dark:text-blue-300">
                      Liều tính theo {patientWeight}kg:{' '}
                      <strong>
                        {Math.min(
                          med.dosage.perKg * patientWeight,
                          med.dosage.maxDose ?? Infinity
                        ).toFixed(0)}{' '}
                        mg
                      </strong>
                    </span>
                    {med.dosage.maxDose && med.dosage.perKg * patientWeight > med.dosage.maxDose && (
                      <span className="text-orange-600 ml-2 text-xs">(đã giới hạn liều tối đa)</span>
                    )}
                  </div>
                ) : (
                  <p className="text-sm">Liều: {med.dosage.fixed} — {med.dosage.frequency}</p>
                )}

                {/* Nursing View */}
                {isNursingView && med.nursingNote && (
                  <div className="mt-2 bg-teal-50 dark:bg-teal-950/30 rounded-lg p-3 border border-teal-200 dark:border-teal-800 space-y-1">
                    <p className="text-xs font-semibold text-teal-700 dark:text-teal-300 uppercase">
                      Hướng dẫn Điều dưỡng
                    </p>
                    <p className="text-sm">🧪 Pha thuốc: {med.nursingNote.preparation}</p>
                    <p className="text-sm">💧 Tốc độ truyền: {med.nursingNote.infusionRate}</p>
                    <div>
                      <p className="text-xs font-medium mt-1">Theo dõi:</p>
                      <ul className="list-disc list-inside text-sm">
                        {med.nursingNote.monitoring.map((m, j) => <li key={j}>{m}</li>)}
                      </ul>
                    </div>
                  </div>
                )}

                {/* Chống chỉ định */}
                {med.contraindications?.length > 0 && (
                  <div className="text-xs text-red-600 dark:text-red-400">
                    ⛔ Chống chỉ định: {med.contraindications.join(', ')}
                  </div>
                )}
              </div>
            ))}
          </TabsContent>

          {/* Tab: Flowchart */}
          <TabsContent value="flowchart" className="mt-4">
            <MermaidFlowchart
              chart={guideline.flowchart.mermaidCode}
              nodes={guideline.flowchart.nodes}
              darkMode={isDark}
            />
          </TabsContent>

          {/* Tab: Cận lâm sàng */}
          <TabsContent value="cls" className="mt-4">
            <div className="space-y-2">
              {guideline.investigations.map((inv, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b dark:border-gray-800">
                  <div>
                    <span className="text-sm font-medium">{inv.name}</span>
                    <span className="text-xs text-gray-500 ml-2">{inv.type}</span>
                  </div>
                  <Badge
                    variant={inv.urgency === 'stat' ? 'destructive' : inv.urgency === 'urgent' ? 'default' : 'secondary'}
                  >
                    {inv.urgency === 'stat' ? '🔴 STAT' : inv.urgency === 'urgent' ? '🟡 Urgent' : 'Routine'}
                  </Badge>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* ── NÚT TẠO PHIẾU BỆNH NHÂN ── */}
        <div className="fixed bottom-6 left-0 right-0 px-4">
          <div className="max-w-3xl mx-auto">
            <Button
              className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-lg"
              onClick={() => setShowPatientEdu(true)}
            >
              📄 Tạo phiếu hướng dẫn bệnh nhân
            </Button>
          </div>
        </div>
      </main>

      {/* ── MODALS / DRAWERS ── */}
      <PatientEducationModal
        open={showPatientEdu}
        onClose={() => setShowPatientEdu(false)}
        guideline={guideline}
      />
      <AuditTrailDrawer
        open={showAudit}
        onClose={() => setShowAudit(false)}
        trail={guideline.auditTrail}
      />
    </div>
  );
}