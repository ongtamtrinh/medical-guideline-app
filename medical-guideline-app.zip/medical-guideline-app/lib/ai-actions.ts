// lib/ai-actions.ts
'use server';
import OpenAI from 'openai';
import type { GuidelineProtocol, PatientEducation } from '@/types/guideline';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generatePatientEducation(
  guideline: GuidelineProtocol
): Promise<PatientEducation> {
  const prompt = `Bạn là bác sĩ tư vấn thân thiện. Dựa trên phác đồ y khoa sau, hãy viết một phiếu hướng dẫn bằng tiếng Việt, ngôn ngữ đơn giản cho bệnh nhân không có kiến thức y khoa.

Phác đồ: ${JSON.stringify({ 
  title: guideline.metadata.title,
  medications: guideline.medications.map(m => ({ name: m.name, dosage: m.dosage, contraindications: m.contraindications })),
  redFlags: guideline.diagnosis.redFlags,
}, null, 2)}

Trả về JSON theo cấu trúc:
{
  "language": "vi",
  "title": "Hướng dẫn chăm sóc tại nhà - [Tên bệnh]",
  "plainTextSummary": "...",
  "medicationGuide": ["...", "..."],
  "dietAdvice": ["...", "..."],
  "warningSignsGoToER": ["...", "..."],
  "followUp": "...",
  "generatedAt": "${new Date().toISOString()}"
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [{ role: 'user', content: prompt }],
    response_format: { type: 'json_object' },
    temperature: 0.4,
  });

  return JSON.parse(response.choices[0].message.content!) as PatientEducation;
}